(function () {
  "use strict";

  /* =========================================================
     Google Maps URL
     Paste the venue's Google Maps link below when available.
     The "View Location" button is hidden/disabled while empty.
     ========================================================= */
  const GOOGLE_MAPS_URL = "";

  const mapsBtn = document.getElementById("mapsBtn");
  if (mapsBtn) {
    if (GOOGLE_MAPS_URL) {
      mapsBtn.href = GOOGLE_MAPS_URL;
    } else {
      mapsBtn.classList.add("is-disabled");
      mapsBtn.setAttribute("aria-disabled", "true");
      mapsBtn.removeAttribute("href");
    }
  }

  /* =========================================================
     Countdown — 25 Oct 2026, 11:42 AM, India/Kerala time (IST, UTC+5:30)
     ========================================================= */
  const target = new Date("2026-10-25T11:42:00+05:30").getTime();

  const els = {
    days: document.getElementById("cd-days"),
    hours: document.getElementById("cd-hours"),
    mins: document.getElementById("cd-mins"),
    secs: document.getElementById("cd-secs"),
  };

  function pad(n) {
    return String(n).padStart(2, "0");
  }

  function tickCountdown() {
    const now = Date.now();
    let diff = target - now;

    if (diff <= 0) {
      els.days.textContent = "00";
      els.hours.textContent = "00";
      els.mins.textContent = "00";
      els.secs.textContent = "00";
      return;
    }

    const day = Math.floor(diff / 86400000);
    diff -= day * 86400000;
    const hour = Math.floor(diff / 3600000);
    diff -= hour * 3600000;
    const min = Math.floor(diff / 60000);
    diff -= min * 60000;
    const sec = Math.floor(diff / 1000);

    els.days.textContent = pad(day);
    els.hours.textContent = pad(hour);
    els.mins.textContent = pad(min);
    els.secs.textContent = pad(sec);
  }

  if (els.days) {
    tickCountdown();
    setInterval(tickCountdown, 1000);
  }

  /* =========================================================
     Scroll reveal
     ========================================================= */
  const revealEls = document.querySelectorAll(".reveal");
  const prefersReducedMotion = window.matchMedia(
    "(prefers-reduced-motion: reduce)"
  ).matches;

  if (prefersReducedMotion || !("IntersectionObserver" in window)) {
    revealEls.forEach((el) => el.classList.add("is-visible"));
  } else {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15, rootMargin: "0px 0px -40px 0px" }
    );
    revealEls.forEach((el) => observer.observe(el));
  }

  /* =========================================================
     Share invitation
     ========================================================= */
  const shareBtn = document.getElementById("shareBtn");
  const shareText =
    "With happiness, we invite you to celebrate the wedding of Anupama & Lijil on 25 October 2026.";
  const shareUrl = window.location.href;

  if (shareBtn) {
    shareBtn.addEventListener("click", async () => {
      if (navigator.share) {
        try {
          await navigator.share({
            title: "Anupama & Lijil | Wedding Invitation",
            text: shareText,
            url: shareUrl,
          });
          return;
        } catch (err) {
          /* user cancelled or share failed — fall through to WhatsApp */
        }
      }
      const waUrl =
        "https://wa.me/?text=" +
        encodeURIComponent(shareText + " " + shareUrl);
      window.open(waUrl, "_blank", "noopener");
    });
  }
})();
